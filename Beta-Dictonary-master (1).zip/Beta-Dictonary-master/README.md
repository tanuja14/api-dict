#  ![# Beta Dictionary ](https://github.com/Helium-He/MyDictonary/blob/master/raw/i.png "Beta Dictonary ") Beta Dictonary

## [Click to Download](https://github.com/Helium-He/MyDictonary/raw/master/raw/MyDictionary.apk)
## Dictionary Android App with beautiful gui



## Features: ##
* Beautiful gui
* History
* defination, synonyms, antonyms, example



## Screenshots ##

![](https://github.com/Helium-He/MyDictonary/blob/master/raw/screenshots.png "Logo Title Text 1")


## Feel free to use for learning purpose... :grin:
Note: App support android version greater than 5.0.






